<template>
  <div class="home">
    <h1>This is a simple rest-api project dashboard.</h1>
  </div>
</template>

<script>
export default {
  name: 'Home',
  components: {
  }
}
</script>
