<template>
  <div class="book">
    <div>
      <b-table striped hover :items="items"></b-table>
    </div>
  </div>
</template>

<script>
export default {
    name: "Book",
    data() {
        return {
            items: null
        }
    },
    mounted() {
        this.$axios
        .get('/book')
        .then(response => {
            console.log(response);
            this.items = response.data.data;
        });
    }
}
</script>